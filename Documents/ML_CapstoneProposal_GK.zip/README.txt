Visualization of the datasets: https://drive.google.com/drive/folders/111zed43osDhVLx4zoIfGNlNwxE0hN6G4?usp=sharing
Software required: Power BI Desktop

Location of datasets:
https://github.com/gergosnoo/ML_capstone_project_SOC_prediction_GK